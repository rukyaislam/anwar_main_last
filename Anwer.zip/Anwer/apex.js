   window.onload = function() {
    document.getElementById('modalOverlay').onclick = function() {
      document.getElementById('modalOverlay').style.display = 'none'
    };

    
  };